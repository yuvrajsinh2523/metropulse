const assert = require('node:assert/strict');
const pause = ms => new Promise(r => setTimeout(r, ms));
async function main() {
  process.env.PORT = '3001';
  require('../server');
  let ready = false;
  for (let i = 0; i < 40; i++) {
    try { await fetch('http://127.0.0.1:3001/api/health'); ready = true; break; } catch { await pause(250); }
  }
  assert(ready, 'server did not become ready');
  const get = async p => { const r = await fetch(`http://127.0.0.1:3001${p}`); assert.equal(r.status, 200); return r.json(); };
  assert.equal((await get('/api/health')).status, 'ok');
  const a = await get('/api/analysis');
  assert.equal(a.totals.yesterday, 47000); assert.equal(a.totals.today, 45200);
  assert(Math.abs(a.totals.percentChange - (-3.829787234)) < 1e-7);
  assert(Math.abs(a.systems[0].percentChange - (-10.714285714)) < 1e-7);
  assert.equal(a.systems[0].status, 'Needs Investigation'); assert.equal(a.alerts[0].priority, 'High');
  const report = await get('/api/report'); assert.equal(report.systems.length, 3); assert.equal(report.incidents.length, 3);
  let r = await fetch('http://127.0.0.1:3001/api/data', { method:'POST', headers:{'content-type':'application/json'}, body:JSON.stringify({meta:{},systems:[{name:'Metro',yesterday:0,today:3},{name:'BRTS',yesterday:10,today:10},{name:'AMTS',yesterday:5,today:5}],incidents:[]}) });
  let body = await r.json(); assert.equal(r.status,200); assert.equal(body.analysis.systems[0].percentChange,null); assert.equal(body.analysis.alerts.length,1); assert.equal(body.analysis.quality.length,1);
  r = await fetch('http://127.0.0.1:3001/api/data', { method:'POST', headers:{'content-type':'application/json'}, body:JSON.stringify({meta:{},systems:[{name:'Bad',yesterday:-1,today:2}]}) });
  assert.equal(r.status,400); assert((await r.json()).errors.length);
  r = await fetch('http://127.0.0.1:3001/api/data', { method:'POST', headers:{'content-type':'application/json'}, body:JSON.stringify({meta:{},systems:[{name:'Metro',yesterday:1,today:1},{name:'BRTS',yesterday:1,today:1}]}) });
  assert.equal(r.status,400); assert((await r.json()).errors.some(e=>e.includes('AMTS')));
  r = await fetch('http://127.0.0.1:3001/api/data/reset',{method:'POST'}); assert.equal(r.status,200);
  console.log('Smoke checks passed: API routes, sample totals, threshold alert, report generation, zero-baseline handling, validation, reset.');
}
main().catch(e=>{ console.error(e); process.exitCode=1; }).finally(()=>process.exit());
