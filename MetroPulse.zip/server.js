const express = require('express');
const fs = require('fs');
const path = require('path');
const { analyze, report } = require('./lib/analysis');
const app = express();
const PORT = Number(process.env.PORT || 3000);
const dataPath = path.join(__dirname,'data','demo.json');
let currentData = JSON.parse(fs.readFileSync(dataPath,'utf8'));
app.use(express.json({limit:'1mb'}));
app.use(express.static(path.join(__dirname,'public')));
app.get('/api/health',(req,res)=>res.json({status:'ok',service:'MetroPulse'}));
app.get('/api/data',(req,res)=>res.json(currentData));
app.get('/api/analysis',(req,res)=>res.json(analyze(currentData)));
app.get('/api/report',(req,res)=>res.json(report(currentData,analyze(currentData))));
app.post('/api/data',(req,res)=>{
  const d=req.body, errors=[];
  if(!d||typeof d!=='object') errors.push('Upload must contain a JSON object.');
  if(!d?.meta||!Array.isArray(d.systems)) errors.push('Required fields: meta and systems array.');
  const names=new Set();
  for(const [i,s] of (d?.systems||[]).entries()){
    if(!s||typeof s.name!=='string'||!s.name.trim()) errors.push(`System ${i+1}: name is required.`);
    else if(names.has(s.name)) errors.push(`Duplicate system name: ${s.name}.`); else names.add(s.name);
    if(s?.yesterday==null||s?.today==null||!Number.isFinite(Number(s.yesterday))||!Number.isFinite(Number(s.today))||Number(s.yesterday)<0||Number(s.today)<0) errors.push(`System ${i+1}: yesterday and today must be non-negative numbers.`);
  }
  for(const required of ['Metro','BRTS','AMTS']) if(!names.has(required)) errors.push(`Required transport system is missing: ${required}.`);
  if(d?.incidents!=null&&!Array.isArray(d.incidents)) errors.push('incidents must be an array.');
  if(Array.isArray(d?.incidents)) for(const [i,incident] of d.incidents.entries()){
    const required=['id','date','system','location','type','severity','description','status'];
    const missing=required.filter(key=>!String(incident?.[key]??'').trim());
    if(missing.length) errors.push(`Incident ${i+1}: missing ${missing.join(', ')}.`);
  }
  if(errors.length) return res.status(400).json({errors});
  currentData=d; res.json({ok:true,analysis:analyze(currentData)});
});
app.post('/api/data/reset',(req,res)=>{ try { currentData=JSON.parse(fs.readFileSync(dataPath,'utf8')); res.json({ok:true}); } catch { res.status(500).json({error:'Unable to load demo data.'}); } });
app.use((err,req,res,next)=>{ if(err instanceof SyntaxError) return res.status(400).json({error:'Invalid JSON request.'}); console.error(err); res.status(500).json({error:'Unexpected server error.'}); });
app.listen(PORT,()=>console.log(`MetroPulse running at http://localhost:${PORT}`));
