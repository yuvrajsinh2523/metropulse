# MetroPulse

Offline-first transport reporting prototype for DevFest Gandhinagar Metro Hacks, PS-13 — “The Two-Minute Morning Brief.” All included counts and incident records are fictional demo data, not verified Ahmedabad transport statistics.

## Run locally

Requirements: Node.js 18 or newer and npm. From this folder:

```sh
npm install
npm start
```

Open <http://localhost:3000>. `npm install` needs to be done once while connected so Express is available locally; after that the app itself makes no external requests and runs offline.

Run the API and calculation smoke checks with `npm test`.

## Architecture

- `server.js`: small Express server, static frontend, JSON API, in-memory replacement/reset for uploaded datasets.
- `lib/analysis.js`: reusable validation-aware calculations, threshold alerts, and report data generation.
- `data/demo.json`: hackathon-editable sample dataset with Metro stations, BRTS/AMTS routes, and incident records.
- `public/`: responsive HTML/CSS/JavaScript interface. Charts are drawn with Canvas, so no remote Chart.js or Bootstrap assets are required.

API endpoints: `GET /api/health`, `/api/data`, `/api/analysis`, `/api/report`; `POST /api/data` validates and loads a dataset; `POST /api/data/reset` restores the bundled demo data.

## Two-minute judge demo

1. On Overview, show the combined 45,200 today vs 47,000 yesterday and the system comparison chart.
2. Point out Metro’s calculated −10.71% change and BRTS +9.09% / AMTS +2.50% values.
3. Open Alerts & Anomalies. Explain the threshold finding and that the Metro gate record is a possible lead, not proof of cause.
4. Open Transport Data to show sample station and route counts plus the incident register.
5. Open Daily Brief and select Generate Daily Brief from Overview (or navigate to the brief, which generates from current data). Download TXT or Print / Save PDF.

## Short pitch

“MetroPulse turns a scattered daily transport snapshot into a two-minute management brief. It compares Metro, BRTS, and AMTS ridership, flags configurable exceptions, surfaces reported incidents as investigation leads, and clearly separates observed facts from possible explanations. The prototype runs locally and works offline, so the reporting flow remains available even with unreliable connectivity.”

## Included features

- Dynamic dashboard totals, day-over-day changes, system filter, Canvas comparison chart, and demo-data labeling.
- Rule-based significant-change alerts (10% default threshold), incident context, and data-quality warnings.
- Location-level tables and incident register.
- Dynamic one-page management brief, TXT download, and print-to-PDF layout.
- Demo load/reset and local JSON upload with useful validation errors.
- Offline frontend with no remote scripts, fonts, APIs, or external data.

## Limitations

This is a local prototype; uploaded data is held in server memory and resets on server restart. Threshold configuration is edited in the dataset’s `meta.thresholdPercent`. The comparison is day over day only. Incident proximity is based on matching system and reporting-period records; no causal inference is made. Bootstrap and Chart.js are not included because their essential layout and chart functionality are implemented locally.
